from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Property

# REQ-2 نموذج إنشاء حساب
class SignupForm(UserCreationForm):
    email = forms.EmailField(required=True)
    class Meta:
        model  = User
        fields = ['username', 'email', 'password1', 'password2']

# REQ-3 نموذج تعديل الحساب
class EditProfileForm(forms.ModelForm):
    class Meta:
        model  = User
        fields = ['username', 'email', 'first_name', 'last_name']

# REQ-6,7 نموذج إضافة وتعديل عقار
class PropertyForm(forms.ModelForm):
    class Meta:
        model  = Property
        fields = [
            'title', 'description', 'price', 'city',
            'address', 'area', 'rooms', 'property_type',
            'status', 'image', 'is_active'
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 4}),
        }