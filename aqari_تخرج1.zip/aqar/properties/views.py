from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate, update_session_auth_hash
from django.contrib.auth.forms import AuthenticationForm, PasswordChangeForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.db.models import Q, Avg, Count
from .models import Property, Favorite, Rating, Report
from .forms import SignupForm, PropertyForm, EditProfileForm

# REQ-1 تسجيل الدخول
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

# REQ-2 إنشاء حساب
def signup_view(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = SignupForm()
    return render(request, 'registration/signup.html', {'form': form})

# REQ-12 تسجيل الخروج
def logout_view(request):
    logout(request)
    return redirect('login')

# REQ-5 الملف الشخصي
@login_required
def profile_view(request):
    my_properties = Property.objects.filter(owner=request.user)\
        .annotate(avg_rating=Avg('rating__score'))
    return render(request, 'properties/profile.html', {'properties': my_properties})

# REQ-3 تعديل الحساب
@login_required
def edit_profile(request):
    if request.method == 'POST':
        form = EditProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'تم تحديث الملف الشخصي')
            return redirect('profile')
    else:
        form = EditProfileForm(instance=request.user)
    return render(request, 'properties/edit_profile.html', {'form': form})

# REQ-4 حذف الحساب
@login_required
def delete_account(request):
    if request.method == 'POST':
        request.user.delete()
        return redirect('login')
    return render(request, 'properties/delete_account.html')

# REQ-28 تغيير كلمة المرور
@login_required
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'تم تغيير كلمة المرور')
            return redirect('profile')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'properties/change_password.html', {'form': form})

# REQ-10 عرض كل العقارات (مع متوسط التقييم)
def property_list(request):
    properties = Property.objects.filter(is_active=True)\
        .annotate(avg_rating=Avg('rating__score'),
                  ratings_count=Count('rating'))\
        .order_by('-created_at')
    return render(request, 'properties/home.html', {'properties': properties})

# REQ-9 تفاصيل العقار (مع التقييم المتوسط)
def property_detail(request, pk):
    property = get_object_or_404(Property, pk=pk)
    property.views_count += 1
    property.save()

    # حساب متوسط التقييم وعدد التقييمات
    ratings_data = Rating.objects.filter(property=property).aggregate(
        avg=Avg('score'), total=Count('id')
    )
    avg_rating = ratings_data['avg'] or 0
    ratings_count = ratings_data['total']

    is_favorite = False
    user_rating = None
    if request.user.is_authenticated:
        is_favorite = Favorite.objects.filter(user=request.user, property=property).exists()
        ur = Rating.objects.filter(user=request.user, property=property).first()
        if ur:
            user_rating = ur.score

    return render(request, 'properties/detail.html', {
        'property': property,
        'is_favorite': is_favorite,
        'avg_rating': avg_rating,
        'ratings_count': ratings_count,
        'user_rating': user_rating,
    })

# REQ-6 إضافة عقار
@login_required
def add_property(request):
    if request.method == 'POST':
        form = PropertyForm(request.POST, request.FILES)
        if form.is_valid():
            property = form.save(commit=False)
            property.owner = request.user
            property.save()
            messages.success(request, 'تم إضافة العقار بنجاح')
            return redirect('home')
    else:
        form = PropertyForm()
    return render(request, 'properties/add_property.html', {'form': form})

# REQ-7 تعديل عقار
@login_required
def edit_property(request, pk):
    property = get_object_or_404(Property, pk=pk, owner=request.user)
    if request.method == 'POST':
        form = PropertyForm(request.POST, request.FILES, instance=property)
        if form.is_valid():
            form.save()
            messages.success(request, 'تم تعديل العقار بنجاح')
            return redirect('detail', pk=pk)
    else:
        form = PropertyForm(instance=property)
    return render(request, 'properties/edit_property.html', {'form': form, 'property': property})

# REQ-8 حذف عقار
@login_required
def delete_property(request, pk):
    property = get_object_or_404(Property, pk=pk, owner=request.user)
    if request.method == 'POST':
        property.delete()
        messages.success(request, 'تم حذف العقار')
        return redirect('profile')
    return render(request, 'properties/delete_property.html', {'property': property})

# REQ-13,14,25 البحث والتصفية
def search_view(request):
    properties = Property.objects.filter(is_active=True)\
        .annotate(avg_rating=Avg('rating__score'))
    query = request.GET.get('q', '')
    city = request.GET.get('city', '')
    ptype = request.GET.get('type', '')
    status = request.GET.get('status', '')
    min_price = request.GET.get('min_price', '')
    max_price = request.GET.get('max_price', '')
    sort = request.GET.get('sort', '-created_at')

    if query:
        properties = properties.filter(Q(title__icontains=query) | Q(description__icontains=query))
    if city:
        properties = properties.filter(city__icontains=city)
    if ptype:
        properties = properties.filter(property_type=ptype)
    if status:
        properties = properties.filter(status=status)
    if min_price:
        properties = properties.filter(price__gte=min_price)
    if max_price:
        properties = properties.filter(price__lte=max_price)

    properties = properties.order_by(sort)
    return render(request, 'properties/search.html', {'properties': properties})

# REQ-37 الأحدث
def newest_view(request):
    properties = Property.objects.filter(is_active=True)\
        .annotate(avg_rating=Avg('rating__score'))\
        .order_by('-created_at')[:20]
    return render(request, 'properties/home.html', {'properties': properties})

# REQ-38 الأكثر مشاهدة (بيانات حقيقية - حسب views_count)
def popular_view(request):
    properties = Property.objects.filter(is_active=True)\
        .annotate(avg_rating=Avg('rating__score'),
                  ratings_count=Count('rating'))\
        .order_by('-views_count')[:20]
    return render(request, 'properties/home.html', {'properties': properties})

# REQ-16 المفضلة
@login_required
def favorites_list(request):
    favorites = Favorite.objects.filter(user=request.user).select_related('property')
    return render(request, 'properties/favorites.html', {'favorites': favorites})

# REQ-15 إضافة للمفضلة
@login_required
def add_favorite(request, pk):
    property = get_object_or_404(Property, pk=pk)
    Favorite.objects.get_or_create(user=request.user, property=property)
    return redirect('detail', pk=pk)

# REQ-17 إزالة من المفضلة
@login_required
def remove_favorite(request, pk):
    property = get_object_or_404(Property, pk=pk)
    Favorite.objects.filter(user=request.user, property=property).delete()
    return redirect('favorites')

# REQ-11 تقييم عقار
@login_required
def rate_property(request, pk):
    property = get_object_or_404(Property, pk=pk)
    if request.method == 'POST':
        score = request.POST.get('score')
        if score:
            Rating.objects.update_or_create(
                user=request.user, property=property,
                defaults={'score': int(score)})
            messages.success(request, 'تم إرسال تقييمك بنجاح')
    return redirect('detail', pk=pk)

# REQ-23 الإبلاغ
@login_required
def report_ad(request, pk):
    property = get_object_or_404(Property, pk=pk)
    if request.method == 'POST':
        reason = request.POST.get('reason')
        Report.objects.create(user=request.user, property=property, reason=reason)
        messages.success(request, 'تم الإبلاغ بنجاح')
        return redirect('detail', pk=pk)
    return render(request, 'properties/report.html', {'property': property})

# REQ-36 المحافظات
def cities_count(request):
    cities = Property.objects.filter(is_active=True)\
        .values('city').annotate(count=Count('id')).order_by('-count')
    return render(request, 'properties/cities.html', {'cities': cities})

# REQ-39 سجل النشاط
@login_required
def activity_history(request):
    my_properties = Property.objects.filter(owner=request.user).order_by('-created_at')
    my_favorites = Favorite.objects.filter(user=request.user).order_by('-added_at')
    return render(request, 'properties/history.html', {
        'properties': my_properties,
        'favorites': my_favorites
    })
