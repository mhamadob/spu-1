from django.contrib import admin
from django.utils.html import format_html
from django.db.models import Avg, Count
from .models import Property, Favorite, Rating, Report


# ════════════════════════════════════════
# إدارة العقارات
# ════════════════════════════════════════
@admin.register(Property)
class PropertyAdmin(admin.ModelAdmin):

    list_display = [
        'property_image_thumb',
        'title',
        'owner',
        'city',
        'formatted_price',
        'property_type',
        'status_badge',
        'avg_rating_display',
        'active_badge',
        'views_count',
        'created_at',
    ]

    list_filter   = ['status', 'property_type', 'is_active', 'city']
    search_fields = ['title', 'city', 'description', 'owner__username']
    ordering      = ['-created_at']
    list_per_page = 15
    date_hierarchy = 'created_at'

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        return qs.annotate(_avg_rating=Avg('rating__score'),
                           _ratings_count=Count('rating'))

    @admin.display(description='الصورة')
    def property_image_thumb(self, obj):
        if obj.image:
            return format_html(
                '<img src="{}" style="width:54px;height:44px;'
                'object-fit:cover;border-radius:8px;">',
                obj.image.url
            )
        return format_html(
            '<div style="width:54px;height:44px;background:#F5F7FA;'
            'border-radius:8px;display:flex;align-items:center;'
            'justify-content:center;color:#FF5A5F;font-size:18px;">🏠</div>'
        )

    @admin.display(description='السعر', ordering='price')
    def formatted_price(self, obj):
        price = f"{int(obj.price):,}"
        return format_html(
            '<span style="color:#FC642D;font-weight:700;">{} ل.س</span>',
            price
        )

    @admin.display(description='الحالة', ordering='status')
    def status_badge(self, obj):
        styles = {
            'sale': ('background:rgba(74,158,255,0.12);color:#4A9EFF;', 'للبيع'),
            'rent': ('background:rgba(255,180,0,0.1);color:#B58A00;', 'للإيجار'),
        }
        style, label = styles.get(obj.status, ('', obj.status))
        return format_html(
            '<span style="{}padding:4px 12px;border-radius:20px;'
            'font-size:11px;font-weight:700;">{}</span>',
            style, label
        )

    @admin.display(description='النشاط', boolean=False, ordering='is_active')
    def active_badge(self, obj):
        if obj.is_active:
            return format_html(
                '<span style="background:rgba(0,166,153,0.12);color:#00A699;'
                'padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;">'
                '✓ نشط</span>'
            )
        return format_html(
            '<span style="background:rgba(0,0,0,0.05);color:#7A7A82;'
            'padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700;">'
            'معطل</span>'
        )

    @admin.display(description='التقييم')
    def avg_rating_display(self, obj):
        avg = getattr(obj, '_avg_rating', None)
        cnt = getattr(obj, '_ratings_count', 0) or 0
        if avg:
            return format_html(
                '<span style="background:rgba(255,180,0,0.12);color:#B58A00;'
                'padding:4px 10px;border-radius:14px;font-size:12px;font-weight:700;">'
                '★ {} <span style="color:#888;font-size:10px;">({})</span></span>',
                f'{avg:.1f}', cnt
            )
        return format_html('<span style="color:#999;font-size:11px;">— لا تقييم</span>')

    fieldsets = (
        ('المعلومات الأساسية', {
            'fields': ('owner', 'title', 'description', 'image'),
        }),
        ('تفاصيل العقار', {
            'fields': (('property_type', 'status'),
                       ('price', 'area', 'rooms')),
        }),
        ('الموقع', {
            'fields': ('city', 'address'),
        }),
        ('الإعدادات', {
            'fields': ('is_active', 'views_count'),
            'classes': ('collapse',),
        }),
    )

    actions = ['activate_properties', 'deactivate_properties']

    @admin.action(description='تفعيل العقارات المحددة')
    def activate_properties(self, request, queryset):
        count = queryset.update(is_active=True)
        self.message_user(request, f'تم تفعيل {count} عقار بنجاح.')

    @admin.action(description='تعطيل العقارات المحددة')
    def deactivate_properties(self, request, queryset):
        count = queryset.update(is_active=False)
        self.message_user(request, f'تم تعطيل {count} عقار.')


# ════════════════════════════════════════
# إدارة المفضلة
# ════════════════════════════════════════
@admin.register(Favorite)
class FavoriteAdmin(admin.ModelAdmin):
    list_display  = ['user', 'property_link', 'added_at']
    search_fields = ['user__username', 'property__title']
    ordering      = ['-added_at']
    list_per_page = 20

    @admin.display(description='العقار')
    def property_link(self, obj):
        return format_html(
            '<span style="color:#FC642D;font-weight:600;">{}</span>',
            obj.property.title
        )


# ════════════════════════════════════════
# إدارة التقييمات
# ════════════════════════════════════════
@admin.register(Rating)
class RatingAdmin(admin.ModelAdmin):
    list_display  = ['user', 'property', 'stars_display', 'score']
    list_filter   = ['score']
    search_fields = ['user__username', 'property__title']
    list_per_page = 20

    @admin.display(description='التقييم')
    def stars_display(self, obj):
        stars_filled = '★' * obj.score
        stars_empty = '☆' * (5 - obj.score)
        return format_html(
            '<span style="font-size:16px;letter-spacing:2px;color:#FFB400;">{}'
            '<span style="color:#ddd;">{}</span></span>',
            stars_filled, stars_empty
        )


# ════════════════════════════════════════
# إدارة البلاغات
# ════════════════════════════════════════
@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display  = ['user', 'property_link', 'short_reason', 'created_at']
    search_fields = ['user__username', 'property__title', 'reason']
    ordering      = ['-created_at']
    list_per_page = 20
    readonly_fields = ['user', 'property', 'reason', 'created_at']

    @admin.display(description='العقار')
    def property_link(self, obj):
        return format_html(
            '<span style="color:#FF5A5F;font-weight:600;">{}</span>',
            obj.property.title
        )

    @admin.display(description='السبب')
    def short_reason(self, obj):
        reason = obj.reason[:50] + '...' if len(obj.reason) > 50 else obj.reason
        return format_html('<span style="color:#8A8A96;">{}</span>', reason)

    def has_add_permission(self, request):
        return False
