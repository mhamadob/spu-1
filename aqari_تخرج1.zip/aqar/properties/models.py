

# Create your models here.
from django.db import models
from django.contrib.auth.models import User

class Property(models.Model):

    # أنواع العقار
    PROPERTY_TYPES = [
        ('apartment', 'شقة'),
        ('villa',     'فيلا'),
        ('land',      'أرض'),
        ('office',    'مكتب'),
    ]

    # حالة العقار
    STATUS = [
        ('sale', 'للبيع'),
        ('rent', 'للإيجار'),
    ]

    owner         = models.ForeignKey(User, on_delete=models.CASCADE)
    title         = models.CharField(max_length=200)
    description   = models.TextField()
    price         = models.DecimalField(max_digits=12, decimal_places=2)
    city          = models.CharField(max_length=100)
    address       = models.CharField(max_length=300)
    area          = models.FloatField()
    rooms         = models.IntegerField()
    property_type = models.CharField(max_length=50, choices=PROPERTY_TYPES)
    status        = models.CharField(max_length=10, choices=STATUS)
    image         = models.ImageField(upload_to='properties/', blank=True, null=True)
    is_active     = models.BooleanField(default=True)
    views_count   = models.IntegerField(default=0)
    created_at    = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class Favorite(models.Model):
    user     = models.ForeignKey(User, on_delete=models.CASCADE)
    property = models.ForeignKey(Property, on_delete=models.CASCADE)
    added_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user} - {self.property}"


class Rating(models.Model):
    user     = models.ForeignKey(User, on_delete=models.CASCADE)
    property = models.ForeignKey(Property, on_delete=models.CASCADE)
    score    = models.IntegerField(choices=[(i, i) for i in range(1, 6)])

    def __str__(self):
        return f"{self.user} - {self.score}"


class Report(models.Model):
    user     = models.ForeignKey(User, on_delete=models.CASCADE)
    property = models.ForeignKey(Property, on_delete=models.CASCADE)
    reason   = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Report by {self.user}"