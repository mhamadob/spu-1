from django.urls import path
from . import views

urlpatterns = [
    # ===== المستخدم =====
    path('login/',           views.login_view,      name='login'),
    path('signup/',          views.signup_view,     name='signup'),
    path('logout/',          views.logout_view,     name='logout'),
    path('profile/',         views.profile_view,    name='profile'),
    path('profile/edit/',    views.edit_profile,    name='edit_profile'),
    path('profile/delete/',  views.delete_account,  name='delete_account'),
    path('change-password/', views.change_password, name='change_password'),

    # ===== العقارات =====
    path('',                          views.property_list,   name='home'),
    path('property/<int:pk>/',        views.property_detail, name='detail'),
    path('property/add/',             views.add_property,    name='add'),
    path('property/<int:pk>/edit/',   views.edit_property,   name='edit'),
    path('property/<int:pk>/delete/', views.delete_property, name='delete_property'),

    # ===== البحث =====
    path('search/',  views.search_view,  name='search'),
    path('newest/',  views.newest_view,  name='newest'),
    path('popular/', views.popular_view, name='popular'),

    # ===== المفضلة =====
    path('favorites/',                   views.favorites_list,   name='favorites'),
    path('favorites/add/<int:pk>/',      views.add_favorite,     name='fav_add'),
    path('favorites/remove/<int:pk>/',   views.remove_favorite,  name='fav_remove'),

    # ===== إضافية =====
    path('property/<int:pk>/rate/',   views.rate_property, name='rate'),
    path('property/<int:pk>/report/', views.report_ad,     name='report'),
    path('cities/',                   views.cities_count,  name='cities'),
    path('history/',                  views.activity_history, name='history'),
]