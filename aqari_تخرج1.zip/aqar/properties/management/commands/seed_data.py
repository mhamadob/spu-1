from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from properties.models import Property, Favorite, Rating
import random

class Command(BaseCommand):
    help = 'إضافة بيانات تجريبية للمشروع'

    def handle(self, *args, **kwargs):
        self.stdout.write('🚀 جاري إضافة البيانات التجريبية...')

        # ===== إنشاء مستخدمين =====
        users_data = [
            {'username': 'ahmed',   'email': 'ahmed@test.com',   'first_name': 'أحمد',   'last_name': 'العمري'},
            {'username': 'sara',    'email': 'sara@test.com',    'first_name': 'سارة',   'last_name': 'الشمري'},
            {'username': 'khalid',  'email': 'khalid@test.com',  'first_name': 'خالد',   'last_name': 'الغامدي'},
            {'username': 'noura',   'email': 'noura@test.com',   'first_name': 'نورا',   'last_name': 'القحطاني'},
            {'username': 'faisal',  'email': 'faisal@test.com',  'first_name': 'فيصل',   'last_name': 'الدوسري'},
        ]

        users = []
        for u in users_data:
            user, created = User.objects.get_or_create(
                username=u['username'],
                defaults={
                    'email':      u['email'],
                    'first_name': u['first_name'],
                    'last_name':  u['last_name'],
                }
            )
            if created:
                user.set_password('test1234')
                user.save()
                self.stdout.write(f'  ✅ تم إنشاء المستخدم: {user.username}')
            users.append(user)

        # ===== بيانات العقارات =====
        properties_data = [
            # شقق
            {
                'title': 'شقة فاخرة في حي النرجس',
                'description': 'شقة فاخرة مساحتها 180م² تتكون من 4 غرف نوم وصالة واسعة ومطبخ مجهز بالكامل. موقع متميز قريب من الخدمات.',
                'price': 85000, 'city': 'الرياض', 'address': 'حي النرجس، شارع الأمير محمد',
                'area': 180, 'rooms': 4, 'property_type': 'apartment', 'status': 'rent',
            },
            {
                'title': 'شقة للبيع في حي العليا',
                'description': 'شقة مميزة في أرقى أحياء الرياض، تشطيب سوبر لوكس، إطلالة رائعة على المدينة.',
                'price': 650000, 'city': 'الرياض', 'address': 'حي العليا، برج المملكة',
                'area': 220, 'rooms': 5, 'property_type': 'apartment', 'status': 'sale',
            },
            {
                'title': 'شقة غرفتين في جدة',
                'description': 'شقة مريحة بغرفتين وصالة، قريبة من البحر والخدمات، مناسبة للعائلات الصغيرة.',
                'price': 35000, 'city': 'جدة', 'address': 'حي الروضة، شارع التحلية',
                'area': 110, 'rooms': 2, 'property_type': 'apartment', 'status': 'rent',
            },
            {
                'title': 'شقة استوديو في الدمام',
                'description': 'استوديو أنيق بتشطيب حديث، مناسب للعزاب والمقيمين للعمل.',
                'price': 22000, 'city': 'الدمام', 'address': 'حي الشاطئ',
                'area': 65, 'rooms': 1, 'property_type': 'apartment', 'status': 'rent',
            },
            # فلل
            {
                'title': 'فيلا فاخرة مع مسبح في الرياض',
                'description': 'فيلا فاخرة على مساحة 600م² تضم 6 غرف نوم ومسبح خاص وحديقة واسعة وغرفة خادمة.',
                'price': 4500000, 'city': 'الرياض', 'address': 'حي الملقا',
                'area': 600, 'rooms': 6, 'property_type': 'villa', 'status': 'sale',
            },
            {
                'title': 'فيلا للإيجار في حي الياسمين',
                'description': 'فيلا دورين بمساحة 400م² مع مجلس ذكوري ومجلس نسائي وغرفة سائق وموقف سيارتين.',
                'price': 120000, 'city': 'الرياض', 'address': 'حي الياسمين',
                'area': 400, 'rooms': 5, 'property_type': 'villa', 'status': 'rent',
            },
            {
                'title': 'فيلا على البحر في جدة',
                'description': 'فيلا رائعة بإطلالة مباشرة على البحر الأحمر، تشطيب فندقي، مناسبة للعائلات الكبيرة.',
                'price': 6500000, 'city': 'جدة', 'address': 'كورنيش جدة',
                'area': 750, 'rooms': 7, 'property_type': 'villa', 'status': 'sale',
            },
            {
                'title': 'فيلا حديثة في الخبر',
                'description': 'فيلا عصرية بتصميم معماري متميز، قريبة من الكورنيش والمراكز التجارية.',
                'price': 3200000, 'city': 'الخبر', 'address': 'حي العزيزية',
                'area': 500, 'rooms': 5, 'property_type': 'villa', 'status': 'sale',
            },
            # أراضي
            {
                'title': 'أرض سكنية في حي الرمال',
                'description': 'أرض سكنية مساحتها 900م² على شارعين، صك نظامي، موقع متميز قريب من الخدمات.',
                'price': 1200000, 'city': 'الرياض', 'address': 'حي الرمال',
                'area': 900, 'rooms': 0, 'property_type': 'land', 'status': 'sale',
            },
            {
                'title': 'أرض تجارية في جدة',
                'description': 'أرض تجارية على شارع رئيسي مساحتها 2000م²، مناسبة للمشاريع التجارية الكبيرة.',
                'price': 8000000, 'city': 'جدة', 'address': 'شارع الأمير سلطان',
                'area': 2000, 'rooms': 0, 'property_type': 'land', 'status': 'sale',
            },
            {
                'title': 'أرض زراعية في القصيم',
                'description': 'أرض زراعية خصبة مساحتها 10000م² مع بئر ماء ونخيل منتج.',
                'price': 500000, 'city': 'القصيم', 'address': 'طريق الرياض-القصيم',
                'area': 10000, 'rooms': 0, 'property_type': 'land', 'status': 'sale',
            },
            # مكاتب
            {
                'title': 'مكتب تجاري في برج معاصر',
                'description': 'مكتب راقٍ في برج حديث، مساحة 250م²، يشمل غرف اجتماعات وصالة استقبال.',
                'price': 180000, 'city': 'الرياض', 'address': 'طريق الملك فهد، برج المملكة',
                'area': 250, 'rooms': 3, 'property_type': 'office', 'status': 'rent',
            },
            {
                'title': 'مكتب صغير في وسط جدة',
                'description': 'مكتب مناسب للشركات الناشئة، مساحة 80م²، بجميع الخدمات والإنترنت.',
                'price': 45000, 'city': 'جدة', 'address': 'وسط المدينة',
                'area': 80, 'rooms': 2, 'property_type': 'office', 'status': 'rent',
            },
            {
                'title': 'مكتب للبيع في الدمام',
                'description': 'مكتب راقٍ للبيع في موقع استراتيجي، مناسب للشركات الكبرى.',
                'price': 950000, 'city': 'الدمام', 'address': 'حي الشاطئ التجاري',
                'area': 320, 'rooms': 4, 'property_type': 'office', 'status': 'sale',
            },
            # إضافية
            {
                'title': 'شقة فندقية في مكة المكرمة',
                'description': 'شقة فندقية مفروشة بالكامل قريبة من المسجد الحرام، مناسبة للمعتمرين والزوار.',
                'price': 95000, 'city': 'مكة المكرمة', 'address': 'أجياد',
                'area': 90, 'rooms': 2, 'property_type': 'apartment', 'status': 'rent',
            },
            {
                'title': 'فيلا في المدينة المنورة',
                'description': 'فيلا هادئة بالقرب من المسجد النبوي الشريف، مناسبة للإقامة والاستثمار.',
                'price': 2800000, 'city': 'المدينة المنورة', 'address': 'حي العزيزية',
                'area': 450, 'rooms': 5, 'property_type': 'villa', 'status': 'sale',
            },
        ]

        # ===== إضافة العقارات =====
        properties = []
        for i, data in enumerate(properties_data):
            owner = users[i % len(users)]
            prop, created = Property.objects.get_or_create(
                title=data['title'],
                defaults={
                    **data,
                    'owner':       owner,
                    'is_active':   True,
                    'views_count': random.randint(10, 500),
                }
            )
            if created:
                self.stdout.write(f'  🏠 تم إضافة: {prop.title}')
            properties.append(prop)

        # ===== إضافة المفضلة =====
        for user in users:
            favs = random.sample(properties, min(4, len(properties)))
            for prop in favs:
                if prop.owner != user:
                    Favorite.objects.get_or_create(
                        user=user, property=prop)

        # ===== إضافة التقييمات =====
        for user in users:
            rated = random.sample(properties, min(5, len(properties)))
            for prop in rated:
                if prop.owner != user:
                    Rating.objects.get_or_create(
                        user=user, property=prop,
                        defaults={'score': random.randint(3, 5)}
                    )

        self.stdout.write('')
        self.stdout.write('✅ تم إضافة البيانات التجريبية بنجاح!')
        self.stdout.write('━' * 40)
        self.stdout.write(f'👥 المستخدمون: {User.objects.count()}')
        self.stdout.write(f'🏠 العقارات:   {Property.objects.count()}')
        self.stdout.write(f'❤️  المفضلة:   {Favorite.objects.count()}')
        self.stdout.write(f'⭐ التقييمات: {Rating.objects.count()}')
        self.stdout.write('━' * 40)
        self.stdout.write('')
        self.stdout.write('🔑 بيانات تسجيل الدخول للمستخدمين التجريبيين:')
        self.stdout.write('   كلمة المرور لجميعهم: test1234')
        for u in users_data:
            self.stdout.write(f'   • {u["username"]}')