from django.contrib import admin

# تخصيص لوحة Admin
admin.site.site_header  = 'عقاري — لوحة التحكم الإدارية'
admin.site.site_title   = 'عقاري'
admin.site.index_title  = 'مرحباً بك في لوحة التحكم'
